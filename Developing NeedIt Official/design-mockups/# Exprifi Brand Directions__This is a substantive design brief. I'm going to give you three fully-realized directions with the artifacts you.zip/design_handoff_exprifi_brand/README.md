# Handoff: Exprifi Brand System ("The Demand Exchange")

## Overview
Brand + UI system for Exprifi (exprifi.com), a reverse marketplace for sports cards (expanding to TCG, comics, coins): buyers post "needs," sellers race to fill them. This handoff finalizes **Direction 3a**: platform-grade light chrome wrapping a signature dark "Live Board" panel. Trust comes from the clean chrome; hunt energy comes from the board.

## About the Design Files
The bundled `Exprifi Brand Directions.dc.html` is a **design reference created in HTML** — a prototype showing intended look and behavior, not production code. The task is to **recreate the finalized design (turn 3, option 3a — topmost section in the file) in the target codebase**: Next.js + Tailwind + shadcn/ui. Turns 1–2 are earlier explorations; ignore them except as context.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and states in option 3a are final. Recreate pixel-faithfully using shadcn/ui primitives and the tokens below.

## Brand

### Wordmark
- `exprifi` — lowercase, Instrument Sans 700, letter-spacing -0.04em, color `#0B0E11`.
- Followed by the "live tick": a rounded green bar (`#00A968`, border-radius 2px, roughly 0.4em wide × 0.14em tall, baseline-aligned with a small gap). **Static — it does not animate.**

### Voice system (exact copy)
- **Hero tagline** (landing H1, app store, socials): `The marketplace that hunts for you.`
- **System line** (sub-head, onboarding, empty states): `The demand exchange — post what you want, sellers come to you.`
- **Split landing doors** (intent, not account type — every user is both):
  - Find side: `Where demand finds supply.` / "Post a need. Watch sellers race to fill it." / CTA "Post a need" (ink button)
  - Sell side: `Where supply finds demand.` / "Browse open needs. Be first to strike the deal." / CTA "Browse the board" (green button)
  - Footer line under the doors: `every account does both — intent, not identity`
- Personality: **Precise / Global / Live**. No chat, DM, or comment metaphors anywhere — negotiation is structured Accept / Counter / Decline only.

## Design Tokens

### Colors (CSS variables for Tailwind / shadcn)
```css
:root {
  /* light chrome (default surface) */
  --background: #FAFAFA;
  --foreground: #0B0E11;
  --card: #FFFFFF;
  --border: #E6E7E9;
  --muted: #EEF0F1;
  --muted-foreground: #6E7378;
  --faint-foreground: #9BA0A6;

  /* brand */
  --primary: #00A968;        /* green on light surfaces */
  --primary-foreground: #FFFFFF;
  --primary-live: #2ED98A;   /* green on dark board */
  --warn: #F5A623;           /* countdown/urgency amber */

  /* dark board panel */
  --board: #101114;
  --board-card: #15171C;     /* elevated rows/photo wells */
  --board-hairline: #1C1E23; /* row separators */
  --board-border: #24262B;   /* panel border + outlined chips */
  --board-foreground: #F2F3F5;
  --board-secondary: #C6CAD0;
  --board-muted: #8A8F96;
  --board-faint: #5C6167;

  /* category accents (extensible per vertical) */
  --cat-tcg: #B78AE8;        /* on #241E2A chip bg */

  --radius: 0.75rem;         /* cards 14px, buttons 8-10px, chips 999px */
}
```
Semantic rules: **money = green mono, always** (`--primary-live` on the board, `--primary`/`#00794B` on light). **Time = amber mono when urgent** (<24h), neutral otherwise. Never use green and amber for anything else.

### Typography
- **Display + body:** Instrument Sans (Google Fonts), weights 400–700. Headings: 700, letter-spacing -0.03/-0.04em.
- **Numerals / data / micro-labels:** Spline Sans Mono (Google Fonts), weights 400–700, with `font-variant-numeric: tabular-nums` so countdowns don't jitter.
- Scale (mobile 390px reference): page title 24px/700; card title 14.5px/600, line-height 1.3; budget 18px/600 mono (21px on featured cards); countdown 12px/500–600 mono; chips/badges 8.5–9.5px mono; body meta 9–10.5px.
- Micro-labels (LIVE BOARD, MAX BUDGET, FIND CARDS) are mono uppercase with letter-spacing .08–.14em.

## Screens / Views

### 1. The Board (home)
- **Layout:** light chrome header (white, 1px bottom border): wordmark left, ink "Post a need" button right (12px/600, padding 8×14, radius 8). Below on `--background`: category pills row (Sports cards active = ink filled; TCG, Comics outlined white; "Coins — soon" dashed border, faint text), then "Open demand" H1 (24px/700) with right-aligned 24h stats in mono ("24h: 312 matched · $48.2k"), then filter row (All active on `--muted` bg; Bulk / Singles / Ending soon / No offers as quiet text buttons).
- **Live Board panel:** `--board` bg, 14px radius, `--board-border` border, 10px horizontal inset from screen edge. Panel header row: "LIVE BOARD" micro-label left; right: static green dot (6px) + "27 open · 84 sellers on" in `--primary-live` mono.
- Rows separated by `--board-hairline` (no gaps, no row radius).

### 2. Need row (component anatomy, priority order)
1. **Type badge** — BULK: filled chip, bg `#1E2A24`, text `--primary-live`. SINGLE: outlined chip, border+text `--primary-live`. Mono 8.5px, radius 999px.
2. **Attribute chips** — sport/condition, mono 8.5px, `--board-muted` text, `--board-border` outline. Category tag for non-default verticals (e.g. TCG: bg `#241E2A`, text `#B78AE8`).
3. **Title** — Instrument Sans 14.5px/600 in `--board-foreground`, 1-line clamp in compact rows, 2-line in featured.
4. **Budget** — bottom-left anchor: `$180` 18px/600 mono in `--primary-live` + tiny ` max` suffix (9px, `--board-muted`).
5. **Countdown** — bottom-right, mono: neutral `--board-secondary` when >24h; amber `--warn` at <24h; **blinking amber + "closing" prefix at <12h** (see Motion).
6. **Offer count** — top-right, mono 9.5px: "3 offers" in `--board-secondary`; "6 offers · racing" in static green when ≥5; "no offers — be first" in green on dashed-border rows.
- Optional reference photo: 42×58 rounded well, `--board-card` striped placeholder, right-aligned.
- Compact row variant: single flex row — title + meta line left, budget over countdown right.
- **States:** hover = 1px `--primary-live` inset border + `rgba(46,217,138,.06)` row tint; active/pressed = `.14` tint. Whole row is the tap target (≥44px).

### 3. Split landing
Centered wordmark, hero tagline as H1 (2 lines), system line beneath; then a 2-column grid of intent doors (see Voice for exact copy), 1px divider between; footer strip on `--background`.

### 4. "It's a match" panel
Dark card (`--board` bg, `--board-border`), 16px radius, 4px top edge in green gradient (`#00A968→#2ED98A→#00A968`). Content centered: 56px check ring (green border, `rgba(46,217,138,.12)` fill, ✓), "It's a match" 24px/700, agreed price 22px green mono, deal meta line ("1996 Topps Kobe Bryant #138 · PSA 9 · 2 counters used"), then buyer/seller avatars (44px circles: buyer dark w/ green ring, seller green filled) joined by `⇄`, usernames in mono, caption "identities revealed · escrow opens next", full-width green CTA "Complete the deal" (radius 10).

## Interactions & Behavior
- Countdowns tick client-side each minute (`2d 04h`, `8h 30m` formats, zero-padded hours, tabular-nums).
- Negotiation is Accept / Counter / Decline with counter budget ("4 counters left", "Your move") — never free-text chat.
- Match panel animates in once: scale .7→1.06→1 with fade, ~500ms ease-out.
- Row press navigates to need detail; hover/active states as above; 150ms ease transitions on border/background only (no transform on board rows).

## Motion Rules (strict — motion has one job)
1. **Blink** (`opacity 1 → .35`, ~1.4s steps) is reserved **exclusively for countdowns under 12h**.
2. Live dot, "racing" labels, wordmark tick: **static**. Presence is shown, not flashed.
3. Match panel: one-shot scale-in, then still.
4. Nothing else on the board animates. Respect `prefers-reduced-motion` (disable blink).

## State Management
- Board: needs list (title, type, category, sport, condition, maxBudget, expiresAt, offerCount, hasPhoto), filter + category state, live counts (open needs, sellers online, 24h matched stats).
- Need detail: offer thread state machine (open → countering(n) → matched/expired), counters remaining per side.
- Match: reveal usernames only post-match; escrow/checkout step follows.

## Assets
No image assets. Wordmark is set in type (Instrument Sans + CSS bar). Reference-photo wells use a 45° striped CSS placeholder until users upload photos. Fonts via Google Fonts: Instrument Sans, Spline Sans Mono.

### 5. Personal page (profile / want board) — turn 4, id `4a`
- Light chrome: identity card (56px ink avatar with initial, `@username` 19px/700, mono meta line, outlined Edit button), trust chips (`✓ 12 DEALS COMPLETED` in green soft chip; close rate + avg match in muted chips), caption: `pseudonymous — your name is shared only when a deal matches`.
- Tabs: Want board / Offers made / Completed (active = ink text + 2px ink underline; counts in mono).
- **Want board = same dark Live Board panel** ("MY OPEN NEEDS" / "3 live"), same row anatomy; owner-specific states: green filled pill `YOUR MOVE — 1 offer`, "3 offers · reviewing", "no offers — boost visibility?".
- Recent deals: white cards with green ✓ circle, title, "matched with @user · date", price in deep green mono.
- Bottom nav (4 tabs): Board / Post / Activity (amber badge) / You.

## Files
- `Exprifi Brand Directions.dc.html` — all explorations; **implement the topmost sections: turn 4 (`4a`, personal page) and turn 3 (`3a`, finalized brand system)**: brand/voice sheet, motion rules, split landing hero, final Board. Turn 2 option `2a` contains the same system pre-finalization (incl. an "It's a match" panel to reference); turn 1 is early exploration.
- `screenshots/01-exprifi.png` — personal page (4a)
- `screenshots/02-exprifi.png` — split landing hero (3a)
- `screenshots/03-exprifi.png` — final Board (3a)
- `screenshots/04-exprifi.png` — brand/voice sheet (3a)
